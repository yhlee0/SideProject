package com.oop2020;
import java.time.LocalDateTime;

public class HospitalAppointment {

	private LocalDateTime time;
	private Doctor doctor;
	private Patient patient;
	
	public HospitalAppointment( Doctor doctor, Patient patient, LocalDateTime time) {
		this.doctor = doctor;
		this.patient = patient;
		this.time = time;
	}
	
	public String toString() { 
		return "HospitalAppointment: " + time.toString() 
				+ "\nDoctor " + doctor.toString()
				+ "\nPatient: " + patient.toString();
	}
}
